package com.capgemini.myapp.controller;

import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.model.QuePaper;
import com.capgemini.myapp.model.Test;

public class AdminLogin {
	
	
	Test test = new Test();
	List<QuePaper> list=new ArrayList<QuePaper>();

	int k=0;
	Scanner sc= new Scanner(System.in);
	public void  adminLogin()
	{
		System.out.println("Enter test Id:");
		int id=sc.nextInt();
		
		
		System.out.println("Enter the number of questions you want to add in the test ");
		int num=sc.nextInt();
		sc.nextLine();
	
		for(int i=1; i<=num;i++)
		{
		
			QuePaper qp=new QuePaper();
			
		     qp.setId(id);
			 qp.setQno(i);
			 System.out.println("Enter the question ");
			 qp.setQue(sc.nextLine());
			 System.out.println("option 1");
			 qp.setOptionA(sc.nextLine());
			 System.out.println("option 2 ");
			 qp.setOptionB(sc.nextLine()); 
			 System.out.println("option 3");
			 qp.setOptionC(sc.nextLine());
			 System.out.println("option 4 ");
			 qp.setOptionD(sc.nextLine());
			 System.out.println("Enter correct option.........  ");
			 qp.setRyt(sc.nextInt());
			 sc.nextLine();
			 list.add(qp);
		}
		
		try {
		  FileOutputStream fout = new FileOutputStream("C:\\Yogesh\\2.txt");
		  ObjectOutputStream oos = new ObjectOutputStream(fout); oos.writeObject(list);
		oos.writeObject(list);
		System.out.println("Test saved Successfully......");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		 
	}
	
	
	
	}
	


