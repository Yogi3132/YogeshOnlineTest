
package com.capgemini.myapp.controller;

import java.util.List;
import java.util.Scanner;

import com.capgemini.myapp.model.QuePaper;

public class UserLogin {
	
	Scanner sc=new Scanner(System.in);
	public void userLogin(List<QuePaper> list) throws InterruptedException
	{
		int marks=0,i,p=0,qn=0; 
		System.out.println("You are ready to go :...");
		/*
		 * System.out.println("Available tests are"); for(QuePaper q11:list)
		 * while(q11.getId()) System.out.print(q11.getId()+"\t");
		 */
		
		
		System.out.println("Enter Test id .....");
		i=sc.nextInt();
		for(QuePaper q1:list)
		{
	      if(q1.getId()==i)
	      {
	    	  qn++;
	    	  p=1;
		  System.out.println("que no :"+q1.getQno());
		   
		   System.out.println(q1.getQue());
		 
		  System.out.println("1  "+q1.getOptionA());
		  System.out.println("2  "+q1.getOptionB());
		  System.out.println("3  "+q1.getOptionC());
		  System.out.println("4  "+q1.getOptionD());
		  
		  System.out.println("Enter your option no:");
		  int res=sc.nextInt();
		 sc.nextLine(); 
		 if(q1.getRyt()==res) {
			 Thread.sleep(1500);
		 System.out.println("Correct Answer");
		 System.out.println("\n\n");
		  marks++;
		  
		 }
		 else
		 {
			 Thread.sleep(1500);
			 System.out.println("Wrong Answer");
			 Thread.sleep(1500);
			 System.out.println("Correct answer is :"+q1.getRyt()+"\n\n");
			 Thread.sleep(2000);
		 }
		 
	  }
		}
		if(p==0)
			System.out.println("no test available for this id  ");
		else
		{
			System.out.println("Wait for your result");
			Thread.sleep(2500);
		  System.out.println("You Scored "+marks+" Marks out of "+qn);
		  System.out.println("----------Test Finished------------\n\n----------THANK YOU------------");
		}
	}
	
		
		
	}	
			
		
