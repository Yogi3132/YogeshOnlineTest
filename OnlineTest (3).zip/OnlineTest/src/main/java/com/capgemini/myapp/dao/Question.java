package com.capgemini.myapp.dao;

public class Question {
	private int questionId;
	private String[] questionOptions;
	private String questionTitle;
	private int questionAnswer;
	private double questionMarks;
	private int chosenAnswer;
	private double marksScored;
	                                
	public Question() {
		super();
		
	}
	public int getQuestionId() 
	{
		return questionId;
	}
	public void setQuestionId(int questionId) 
	{
		this.questionId = questionId;
	}
	public String[] getQuestionOptions() 
	{
		return questionOptions;
	}
	public void setQuestionOptions(String[] questionOptions) 
	{
		this.questionOptions = questionOptions;
	}
	public String getQuestionTitle() 
	{
		return questionTitle;
	}
	public void setQuestionTitle(String questionTitle) 
	{
		this.questionTitle = questionTitle;
	}
	public int getQuestionAnswer() 
	{
		return questionAnswer;
	}
	public void setQuestionAnswer(int questionAnswer) 
	{
		this.questionAnswer = questionAnswer;
	}
	public double getQuestionMarks() 
	{
		return questionMarks;
	}
	public void setQuestionMarks(double questionMarks) 
	{
		this.questionMarks = questionMarks;
	}
	public int getChosenAnswer() 
	{
		return chosenAnswer;
	}
	public void setChosenAnswer(int chosenAnswer)
	{
		this.chosenAnswer = chosenAnswer;
	}
	
	@Override
	public String toString() {
		
		return super.toString();
	}
	public double getMarksScored() {
		return marksScored;
	}
	public void setMarksScored(double marksScored) {
		this.marksScored = marksScored;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
