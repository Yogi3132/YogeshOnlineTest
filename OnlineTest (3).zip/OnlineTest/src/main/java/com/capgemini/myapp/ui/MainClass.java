package com.capgemini.myapp.ui;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.capgemini.myapp.controller.AdminLogin;
import com.capgemini.myapp.controller.QuestionsService;
import com.capgemini.myapp.controller.UserLogin;
import com.capgemini.myapp.dao.Question;
import com.capgemini.myapp.model.*;

public class MainClass implements Serializable {

	public static void main(String[] args) throws IOException, InterruptedException {
		List<QuePaper> list=new ArrayList<QuePaper>();
		try {
			  File f=new File("C:\\Yogesh\\2.txt");
			  FileInputStream fout = new FileInputStream("C:\\Yogesh\\2.txt");
			  ObjectInputStream oos = new ObjectInputStream(fout);
			  Object obj=oos.readObject();
			  
			  if(obj==null)
			  {
				  System.out.println("NO test saved ");
			  }
			  else
			  {
				  
				 list=(List<QuePaper>) obj;
			  }			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			 
		Map<Integer, String> map = new HashMap<Integer, String>();
		Map<Integer, String> questions = new HashMap<Integer, String>();
		Map<Integer, String> answers = new HashMap<Integer, String>();
		map.put(1, "admin");
		map.put(2, "user");
	
	
		Test test = new Test();
		User user = new User();
		Question question=new Question();
		QuestionsService qs=new QuestionsService();
		
		Scanner sc = new Scanner(System.in);
		String q,a;
		System.out.println("-----------------WELCOME TO ONLINE TEST--------------------");
		System.out.println("----------------------------Enter--------------------------\n"
				+ 			"-------------------------1-Admin login---------------------\n"
				+ 			"-------------------------2-User login----------------------\n"
				);
		int userId = sc.nextInt();
		sc.nextLine();
		System.out.println("�nter Password");
		String password = sc.nextLine();
		
		
		if (userId == 1 && password.equalsIgnoreCase(map.get(1)))
		{
			System.out.println("-------------------Admin Login Successful------------------");

			System.out.println("-----------------Would you like to add Test----------------\n"
					+ "-------------------YES/NO------------------");
			String re=sc.nextLine();
			if(re.equalsIgnoreCase("yes"))
			{
				new AdminLogin().adminLogin();
			
			}
			else if(re.equalsIgnoreCase("NO"))
			{
				System.out.println("--------------THANK YOU--------------");
			}
			else
				   System.out.println("-----------WRONG CHOICE-------------");
				
		}
		 else if(userId == 2 && password.equalsIgnoreCase(map.get(2)))
		{
			System.out.println("-------------------USER Login Successful------------------");
			new UserLogin().userLogin(list);
		}
		else
			System.out.println("-----------------WRONG id OR password --------------------");
		
		
	}

}